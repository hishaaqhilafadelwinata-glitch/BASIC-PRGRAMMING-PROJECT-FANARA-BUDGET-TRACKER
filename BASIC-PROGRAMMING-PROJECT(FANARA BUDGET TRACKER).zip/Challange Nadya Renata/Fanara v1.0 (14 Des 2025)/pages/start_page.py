import flet as ft

class Icon(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        self.content= ft.Column(
            controls=[
                ft.Image(src="icon.png",width=100, height=100)
            ],
            horizontal_alignment= ft.CrossAxisAlignment.CENTER
        )

class Button(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        self.content= ft.Column(
            controls=[
                ft.ElevatedButton(
                    width=180, height=40, color='white',
                    text='Get Started', bgcolor="#1c85ba",
                    style=ft.ButtonStyle(
                        shape= ft.RoundedRectangleBorder(radius=20),
                        side=ft.BorderSide(1, "#1c85ba")
                    ),
                    on_click=self.click,
                    on_hover=self.hover,
                    animate_scale=ft.Animation(300, ft.AnimationCurve.EASE_OUT)
                )
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    def hover(self, e):
        e.control.scale=1.05 if e.data =='true' else 1
        e.control.update()
    def click(self, e):
        e.page.go('/home') if e.page.client_storage.contains_key("Saved Name") else e.page.go('/login')

class StartContent(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        # self.border_radius= ft.border_radius.only(
        #     top_left=1000, top_right=1000)
        # self.border= ft.border.only(top=ft.border.BorderSide(1, "#196420"),
        #                             right=ft.border.BorderSide(1, "#196420"),
        #                             left=ft.border.BorderSide(1, "#196420"))
        # self.bgcolor= "#FFFFFF"
        self.content= ft.Container(
            content=ft.Column(
                controls=[
                    ft.Image("icon.png", height=120, width=120),
                    Button()
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER
            ),
            alignment=ft.alignment.center
        )

class StartPage(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route='/')
        self.main_content= StartContent()
        self.alignment= ft.alignment.center
        self.page= page
        self.controls=[
            ft.Stack(
                controls=[
                    ft.Image(
                        src="startlogin_page.png", height=float("inf"),
                        fit=ft.ImageFit.COVER, width=float("inf")
                    ),
                    self.main_content
                ],
                expand=True,
                alignment=ft.alignment.center
            )
        ]
        self.padding=0
        self.spacing=0
        self.resize_content(None)
        
    def resize_content(self, e):
        new_width= min(self.page.window.width*0.8, 400)
        self.main_content.width= new_width
        self.main_content.update