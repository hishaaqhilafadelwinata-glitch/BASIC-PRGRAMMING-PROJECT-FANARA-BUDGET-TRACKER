import flet as ft
import json
import os
folder = "Database"
file = "Username.json"
current_dir = os.path.abspath(__file__)
pages_folder = os.path.dirname(current_dir)
database_folder = os.path.join(pages_folder, folder)
full_path = os.path.join(database_folder, file)

class LoginTitle(ft.Container):
    def __init__(self):
        super().__init__()
        self.padding=ft.padding.only(left=20, right=20, top=50, bottom=10)
        self.margin=ft.margin.only(left=20, right=20, top=50, bottom=10)
        self.content= ft.Column([
            ft.Icon(ft.Icons.PERSON,
                    size=100,
                    color= 'blue'),
            ft.Text('Welcome!',  size= 38, color = '#3b3669'),
            ft.Text("How should we call you?", size = 20, color= '#3b3669')],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
        self.alignment=ft.alignment.center

class InputName(ft.TextField):
    def __init__(self):
        super().__init__()
        self.label='Fill in here'
        self.hint_text= 'e.g Nadya Renata'
        self.color= "#3b3669"
        self.text_size= 14
        self.text_style=ft.TextStyle(weight=ft.FontWeight.BOLD)
        self.label_style=ft.TextStyle(color="#3b3669")
        # self.focused_border_color= "#2D2D2D"
        self.value = ""
        self.border_radius= 25
        self.filled= True
        self.fill_color= 'white'
        self.text_align=ft.TextAlign.CENTER
        self.width= 200


class ContinueButton(ft.ElevatedButton):
    def __init__(self, input_name):
        super().__init__()
        self.text = 'Continue'
        self.bgcolor = "#1c85ba"
        self.color = "#FFFFFF"
        self.width = 160
        self.height = 40
        self.input_ref = input_name
        self.on_click= self.save_name 
        self.style= ft.ButtonStyle(side=ft.BorderSide(width=1, color="#FFFFFF"))
        
    def save_name(self, e):
        username = self.input_ref.value.strip()
        if not username:
            e.page.snack_bar = ft.SnackBar(
                ft.Text("Please input your name."), bgcolor='red'
            )
            e.page.open(e.page.snack_bar)
            e.page.update()
        else:
            e.page.client_storage.set("Saved Name", username)
            e.page.go('/home')
        
class LoginContent(ft.Container):
    def __init__(self):
        super().__init__()
        # self.alignment= ft.alignment.center
        # self.border_radius= ft.border_radius.only(
        #     top_left=1000, top_right=1000)
        # self.border= ft.border.only(top=ft.border.BorderSide(1, "#FFC93D"),
        #                             right=ft.border.BorderSide(1, "#FFC93D"),
        #                             left=ft.border.BorderSide(1, "#FFC93D"))
        # self.bgcolor= "#FFFFFF"
        name= InputName()
        button = ContinueButton(input_name=name)
        self.content= ft.Container(
            content=ft.Column(
                controls=[
                    ft.Column(
                        controls=[
                            ft.Text("Welcome!", size=30, 
                            color="#3b3669", weight=ft.FontWeight.BOLD),
                            ft.Text("How should we call you?", size=15, 
                            color="#3b3669", italic=True)
                        ],
                        spacing=0,
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER
                    ),
                    name,
                    button
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER, spacing=20
            ),
            alignment=ft.alignment.center,
        )

class Login(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route='/login')
        self.page=page
        self.main_content= LoginContent()
        self.controls=[ft.Stack(
            controls=[
                ft.Image("startlogin_page.png", fit=ft.ImageFit.COVER,
                         width=float("inf"), height=float("inf")),
                self.main_content
                ],
            expand=True,
            alignment=ft.alignment.center
            )
        ]
        self.padding=0
        self.horizontal_alignment= ft.CrossAxisAlignment.CENTER
        self.resize_content(None)
    def resize_content(self, e):
        new_height= min(self.page.window.height*0.85, 700)
        new_width= min(self.page.window.width*0.85, 400)
        self.main_content.width= new_width
        self.main_content.height= new_height
        self.main_content.update
