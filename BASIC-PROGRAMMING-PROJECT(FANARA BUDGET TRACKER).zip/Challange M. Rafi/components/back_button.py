import flet as ft

class BackButton(ft.Container):
    def __init__(self):
        super().__init__()
        self.bgcolor="#7F77F1"
        self.alignment=ft.alignment.top_center
        self.border_radius= 20
        self.padding= ft.padding.only(top=8)
        self.shadow= ft.BoxShadow(blur_radius=15, color=ft.Colors.BLACK12)
        self.width=40
        self.height=40
        self.content= ft.Column(controls=[ft.Icon(
            ft.Icons.HOME_ROUNDED, size=25, color="#FFFFFF"
        )])
        self.on_click= self.click

    def click(self, e):
        e.page.go('/home')