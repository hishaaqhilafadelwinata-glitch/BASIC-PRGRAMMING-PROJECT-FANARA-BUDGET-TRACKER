import flet as ft

class HeaderHome(ft.Container):
    def __init__(self, name):
        super().__init__()
        self.width=400
        self.height=120
        self.bgcolor='#FFFFFF'
        self.alignment= ft.alignment.center
        self.content= ft.Row(
            controls=[
                ft.Container(content=ft.Icon(
                     ft.Icons.PERSON, size=40, color="#C8D0FF"
                ),
                border=ft.border.all(1, "#2D2D2D"),
                border_radius=10000,
                bgcolor="#5465FF",
                expand=False,
                width=50,height=50,
                alignment=ft.alignment.center),
                ft.Container(width=10),
                ft.Column([
                    ft.Text(f"Hi, {name}", 
                        size=14, italic=True, color="#0C48A6"
                        ),
                    ft.Text(
                        "Welcome to Fanara Budget Tracker!", size=15, color="#0C48A6",
                        weight=ft.FontWeight.BOLD
                    )
            ], 
            spacing=0,
            alignment=ft.MainAxisAlignment.CENTER),
            ft.IconButton(
                icon=ft.Icons.LOGOUT,
                icon_color="#0C48A6",
                tooltip="Logout",
                on_click= self.click_logout,
                icon_size=18
            )
        ], 
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=0)

    def click_logout(self, e):
            pop_up = ft.AlertDialog(
                title=ft.Text("Log Out"),
                content=ft.Text("Are you sure?"),
                actions=[
                    ft.ElevatedButton(
                        text="Yes",
                        on_click= lambda e: e.page.go('/login'),
                        color="blue",
                        bgcolor=None
                    ),
                    ft.ElevatedButton(
                        text="No",
                        on_click=lambda e: e.page.close(pop_up),
                        color='red',
                        bgcolor= None
                    ),
                ],
                actions_alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                modal=True
            )
            e.page.open(pop_up)