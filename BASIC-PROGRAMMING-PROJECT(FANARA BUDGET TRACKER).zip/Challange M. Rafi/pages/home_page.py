import flet as ft
from components.header_home import HeaderHome
from components.dashboard_cards import  DashboardCard
from components.transaction_list import TransactionList

class HomeContent(ft.Container):
    def __init__(self, user):
        super().__init__()
        self.alignment= ft.alignment.center
        self.dashboard= DashboardCard()
        self.content= ft.Column(
            controls=[
                HeaderHome(name=user),
                self.dashboard,
                ft.Container(content=ft.Text("Recent Transactions", size=20, 
                                             color="#2D2D2D", weight=ft.FontWeight.BOLD),
                            alignment=ft.alignment.center_left,
                            width=400, padding=20),
                TransactionList(on_delete_update=self.dashboard.update_data)
            ],
            spacing=10,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
class PlusButton(ft.FloatingActionButton):
    def __init__(self):
        super().__init__()
        self.icon= ft.Icons.ADD
        self.bgcolor= "#E8DBFF"
        self.tooltip='Add Transaction'
        self.foreground_color= "#6362D7"
        self.on_click= self.click
    def click(self, e):
        if e.page.client_storage.contains_key("Edit data"):
            e.page.client_storage.remove("Edit data")
        e.page.go('/transaction')
class Home(ft.View):
    def __init__(self, username):
        super().__init__(route='/home')
        self.floating_action_button= PlusButton()
        self.floating_action_button_location= ft.FloatingActionButtonLocation.CENTER_DOCKED
        self.main_content= HomeContent(user=username)
        self.controls=[
            self.main_content
        ]
        self.padding=0
        self.bgcolor='#FFFFFF'
        self.horizontal_alignment= ft.CrossAxisAlignment.CENTER