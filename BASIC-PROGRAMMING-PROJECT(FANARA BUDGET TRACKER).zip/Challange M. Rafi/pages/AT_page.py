import flet as ft
from components.back_button import BackButton
class HeaderAddTransaction(ft.Container):
    def __init__(self):
        super().__init__()
        self.width= 400
        self.height=120
        self.padding=20
        self.bgcolor= "#F8F9FA"
        self.content= ft.Row(
            controls= [BackButton(),
                       ft.Text("Add Transaction", size=20, 
                               color='#6362D7', italic=True,
                               weight=ft.FontWeight.BOLD)]
        )
        self.shadow= ft.BoxShadow(blur_radius=15, color=ft.Colors.BLACK12)

class IncomeExpenseCard(ft.Container):
    def __init__(self):
        super(). __init__()
        self.content=ft.Column(
            controls=[
                ft.Column(
                    controls=[
                        ft.Text("Received any money today? Add it here.",
                                color="#2D2D2D", italic=True, size=15,
                                weight=ft.FontWeight.BOLD),
                        self.create_card(bgcolor='#9ED864', icon=ft.Icons.ARROW_UPWARD, 
                                        label='Income', description='Add a new transaction', 
                                        adress='/income', iconcolor="#9ED864", iconbgcolor="#196420")
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=0
                ),
                ft.Column(
                    controls=[
                        ft.Text("What did you spend on today? Add it here.",
                                color="#2D2D2D", italic=True, size=15,
                                weight=ft.FontWeight.BOLD),
                        self.create_card(bgcolor='#FF7D7D', icon=ft.Icons.ARROW_DOWNWARD, 
                                    label='Expense', description='Add a new transaction', 
                                    adress='/expense', iconcolor="#FF7D7D", iconbgcolor="#B10000"),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=0
                ),
                ft.Container(
                    height=150
                )
            ],
            spacing=15,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
        self.padding=20
        self.expand=True
    def create_card(self, bgcolor, icon, iconcolor, iconbgcolor, label, description, adress):
        return ft.Container(
            bgcolor= bgcolor,
            border_radius=20,
            border=ft.border.all(1, "#2D2D2D"),
            width=350,
            content=ft.Row(
                    [
                ft.Container(
                    content= ft.Icon(icon, size=30, color=iconcolor),
                    alignment=ft.alignment.center,
                    bgcolor=iconbgcolor,
                    border_radius=1000
                ),
                ft.Column(
                    controls=[
                        ft.Text(label, size= 24, color=iconbgcolor, 
                                weight=ft.FontWeight.BOLD, italic=True),
                        ft.Text(description, size = 13, 
                                color=iconbgcolor, italic=True,
                                weight=ft.FontWeight.BOLD)
                        ],
                    spacing=0
                    )
                ], 
            alignment= ft.MainAxisAlignment.START,
            ),
            padding=20,
            margin=ft.margin.symmetric(vertical=10),
            ink=True,
            on_click=lambda e: e.page.go(adress),
            ink_color = ft.Colors.with_opacity(0.15, ft.Colors.RED_900),
            on_hover=self.hover,
            animate_scale=ft.Animation(300, ft.AnimationCurve.EASE_OUT)
        )
    def hover(self, e):
        e.control.scale=1.05 if e.data =='true' else 1
        e.control.update()    

class ATPage(ft.View):
    def __init__(self):
        super().__init__(route='/transaction')
        self.padding=0
        self.bgcolor= "#FFFFFF"
        self.horizontal_alignment=ft.CrossAxisAlignment.CENTER
        self.controls=[
            HeaderAddTransaction(),
            IncomeExpenseCard()
        ]