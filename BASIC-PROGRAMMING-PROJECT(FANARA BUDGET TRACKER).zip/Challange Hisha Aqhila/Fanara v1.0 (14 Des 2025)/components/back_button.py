import flet as ft

class BackButton(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment=ft.alignment.center
        self.padding=20
        self.width=350
        self.content= ft.ElevatedButton(
            content=ft.Row(
                controls=[
                    ft.Icon(
                        ft.Icons.ARROW_BACK,
                        color="#FFFFFF",
                        size=20
                    ),
                    ft.Text("Back", size=16, 
                            color="#FFFFFF", 
                            weight=ft.FontWeight.BOLD)
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=10,
                tight=True
            ),
            bgcolor="#1E4478",
            width=150,
            height=45,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
                side=ft.BorderSide(1.5, "#0A1E3D"),
                shadow_color="#1E4478",
                elevation=6
            ),
            on_click=lambda e: e.page.go('/home'),
            on_hover=self.hover,
            animate_scale=ft.Animation(300, ft.AnimationCurve.EASE_OUT)
        )
    
    def hover(self, e):
        if e.data == 'true':
            e.control.scale=1.05
            e.control.elevation=10
        else:
            e.control.scale=1
            e.control.elevation=6
        e.control.update()