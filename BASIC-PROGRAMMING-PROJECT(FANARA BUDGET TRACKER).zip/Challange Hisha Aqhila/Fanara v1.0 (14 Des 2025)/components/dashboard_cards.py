import flet as ft
from utils.summation import InEx_total, total

class DashboardCard(ft.Container):
    def __init__(self):
        super().__init__()
        self.bgcolor= "#FFFFFF"
        self.width= 350
        self.height= 240
        self.padding= 22
        self.border_radius= 20
        
        self.balance_text= ft.Text(
            f"IDR {total()}", 
            size=36, 
            weight=ft.FontWeight.BOLD, 
            color='#434A54',
            tooltip=f"{total}", 
            no_wrap=True,
            overflow=ft.TextOverflow.ELLIPSIS
        )
        
        self.content= ft.Column(
            controls=[
                ft.Text(
                    "Total Balance", 
                    size=13, 
                    color="#AAB2BD", 
                    weight=ft.FontWeight.W_500
                ),
                self.balance_text,
                ft.Container(height=20),
                ft.Row(
                    controls=[
                        self.IncExp_card(
                            icon=ft.Icons.ARROW_DOWNWARD_ROUNDED, 
                            iconclr="#FFFFFF", 
                            iconbgclr="#A0D468",
                            label="Income", 
                            amount=InEx_total()[0], 
                            labelclr="#656D78",
                            amountclr="#A0D468"
                        ),
                        self.IncExp_card(
                            icon=ft.Icons.ARROW_UPWARD_ROUNDED, 
                            iconclr="#FFFFFF", 
                            iconbgclr="#ED5565",
                            label="Expense", 
                            amount=InEx_total()[1], 
                            labelclr="#656D78",
                            amountclr="#ED5565"
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    spacing=12
                )
            ],
            spacing=2, 
            horizontal_alignment=ft.CrossAxisAlignment.START
        )
        
        self.on_hover= self.hover
        self.animate_scale= ft.Animation(300, ft.AnimationCurve.EASE_OUT)
        self.border= ft.border.all(1.5, "#E6E9ED")
        self.shadow= ft.BoxShadow(
            spread_radius=0,
            blur_radius=12,
            offset=ft.Offset(0, 4)
        )
        
    def hover(self, e):
        e.control.scale= 1.02 if e.data == 'true' else 1
        if e.data == 'true':
            e.control.shadow= ft.BoxShadow(
                spread_radius=2,
                blur_radius=20,
                color=ft.Colors.with_opacity(0.15, "#5D9CEC"),
                offset=ft.Offset(0, 6)
            )
        else:
            e.control.shadow= ft.BoxShadow(
                spread_radius=0,
                blur_radius=12,
                color=ft.Colors.with_opacity(0.08, "#656D78"),
                offset=ft.Offset(0, 4)
            )
            e.control.border= ft.border.all(1.5, "#E6E9ED")
        e.control.update()    

    def IncExp_card(self, icon, iconclr, iconbgclr, label, amount, labelclr, amountclr):
        return ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        ft.Container(
                            width=40, 
                            height=40, 
                            border_radius=10,
                            bgcolor=iconbgclr, 
                            alignment=ft.alignment.center,
                            content=ft.Icon(icon, color=iconclr, size=22)
                        ),
                        ft.Text(label, size=14, color=labelclr, weight=ft.FontWeight.W_600),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10
                ),
                ft.Container(height=8),
                ft.Text(
                    amount, 
                    size=20,
                    color=amountclr, 
                    weight=ft.FontWeight.BOLD, 
                    tooltip=amount, 
                    no_wrap=True,
                    overflow=ft.TextOverflow.ELLIPSIS
                )
            ], 
            spacing=0,
            horizontal_alignment=ft.CrossAxisAlignment.START
        )
    
    def update_data(self):
        new_total = total()
        new_inc_exp = InEx_total()
        
        self.balance_text.value= f"IDR {new_total}"
        self.balance_text.tooltip= f"{new_total}"

        # Income is the first column in row
        income_column = self.content.controls[3].controls[0]
        income_column.controls[2].value = new_inc_exp[0]
        income_column.controls[2].tooltip = new_inc_exp[0]

        # Expense is the second column in row
        expense_column = self.content.controls[3].controls[1]
        expense_column.controls[2].value = new_inc_exp[1]
        expense_column.controls[2].tooltip = new_inc_exp[1]

        self.update()