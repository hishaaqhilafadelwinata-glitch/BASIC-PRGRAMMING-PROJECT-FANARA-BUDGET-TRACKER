import flet as ft
import json
import os
from utils.transactions import delete_data
from components.dashboard_cards import DashboardCard

folder_dir = "Database"
file_dir = "Data.json"
current_file = os.path.abspath(__file__)
pages_folder = os.path.dirname(current_file)
project_folder = os.path.dirname(pages_folder)
data_folder = os.path.join(project_folder, folder_dir)
full_path = os.path.join(data_folder, file_dir)

class TransactionList(ft.Container):
    def __init__(self, on_delete_update):
        super().__init__()
        self.alignment= ft.alignment.top_center
        self.height= 400
        self.width= 400
        self.bgcolor= "#FFFFFF"
        self.clip_behavior= ft.ClipBehavior.ANTI_ALIAS
        self.on_delete_update= on_delete_update
        self.expand=True
        
        # Modern Flattastic Color Palette untuk kategori
        self.icon_dict={
            # Income categories - warna cerah dan positif
            "Salary": [ft.Icons.MONETIZATION_ON, "#A0D468"],      # Grass - hijau segar
            "Dividen": [ft.Icons.CASES, "#48CFAD"],               # Mint - tosca
            "Gift": [ft.Icons.WALLET_GIFTCARD, "#FFCE54"],        # Sunflower - kuning
            
            # Expense categories - warna beragam dan menarik
            "Food": [ft.Icons.RESTAURANT, '#FC6E51'],             # Bittersweet - orange
            "Transportation": [ft.Icons.DIRECTIONS_CAR, '#4FC1E9'], # Aqua - biru muda
            "Lifestyle": [ft.Icons.WEEKEND, '#AC92EC'],           # Lavender - ungu
            "Health": [ft.Icons.HEALTH_AND_SAFETY, '#ED5565'],    # Grapefruit - merah
            "Electrical": [ft.Icons.ELECTRIC_BOLT, '#5D9CEC'],    # Blue Jeans - biru
            "Education": [ft.Icons.SCHOOL, '#4FC1E9'],            # Aqua
            "Entertainment": [ft.Icons.MOVIE, '#EC87C0'],         # Pink Rose
            "Others": [ft.Icons.MORE_HORIZ, "#AAB2BD"],           # Medium Gray
            None: [ft.Icons.QUESTION_MARK, "#CCD1D9"]             # Light Gray
        }
        self.content=self.show_transaction()
        
    def show_transaction(self):
        empty_widget = ft.Column(
            controls=[
                ft.Icon(ft.Icons.RECEIPT_LONG_OUTLINED, size=80, color="#AAB2BD"),
                ft.Text("Your transactions will show here", size=15, 
                        color="#656D78", italic=True,
                        weight=ft.FontWeight.W_500),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10
        )
        
        if not os.path.exists(full_path):
            return ft.Column(
                controls=[
                    self.create_title(),
                    ft.Container(
                        content=empty_widget,
                        expand=True
                    )
                ],
                spacing=0
            )
            
        try:
            container_list = ft.Column(
                spacing=8, 
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                scroll=ft.ScrollMode.HIDDEN,
                expand=True,
                controls=[
                    ft.Container(height=15)  # Spacing lebih kecil dari 80
                ]
            )
            
            with open(full_path, 'r') as file:
                data = json.load(file)
                
            if not data:
                return ft.Column(
                    controls=[
                        self.create_title(),
                        ft.Container(
                            content=empty_widget,
                            expand=True
                        )
                    ],
                    spacing=0
                )
                
            for transaction in data:
                data_id = transaction["id"]
                label = transaction["title"]
                date = transaction["date"]
                amount = transaction["amount"]
                tipe = transaction["Type"]
                category = transaction["Category"]
                icon_data = self.icon_dict[category][0]
                bgicon_data = self.icon_dict[category][1]
                
                container = self.create_container(
                    dataid=data_id, 
                    label=label,
                    date=date, 
                    amount=amount,
                    sublabel=category, 
                    tipe=tipe,
                    icon=icon_data, 
                    bgicon=bgicon_data
                )
                container_list.controls.append(container)
                
            container_list.controls.append(ft.Container(height=100))
            
            shader_mask = ft.ShaderMask(
                content=container_list,
                blend_mode=ft.BlendMode.DST_IN,
                shader=ft.LinearGradient(
                    begin=ft.alignment.top_center,
                    end=ft.alignment.bottom_center,
                    colors=[
                        ft.Colors.TRANSPARENT, 
                        ft.Colors.BLACK, 
                        ft.Colors.BLACK, 
                        ft.Colors.TRANSPARENT
                    ],
                    stops=[0.0, 0.05, 0.95, 1.0],
                )
            )
            
            return ft.Column(
                controls=[
                    self.create_title(),
                    ft.Container(
                        content=shader_mask,
                        expand=True
                    )
                ],
                spacing=0
            )
            
        except json.JSONDecodeError:
            return ft.Column(
                controls=[
                    self.create_title(),
                    ft.Container(
                        content=empty_widget,
                        expand=True
                    )
                ],
                spacing=0
            )
    
    def create_title(self):
        """Membuat header title untuk Transaction List"""
        return ft.Container(
            padding=ft.padding.only(top=15, bottom=10, left=20, right=20),
            content=ft.Row(
                controls=[
                    ft.Icon(
                        ft.Icons.RECEIPT_LONG,
                        size=28,
                        color="#434A54"
                    ),
                    ft.Text(
                        "Transaction List",
                        size=22,
                        weight=ft.FontWeight.BOLD,
                        color="#434A54"
                    )
                ],
                spacing=10,
                alignment=ft.MainAxisAlignment.CENTER
            )
        )
            
    def create_container(self, dataid, label, amount, date, tipe, 
                        sublabel, icon, bgicon, amount_col=''):
        amount = f"+{amount}" if tipe == 'Income' else f"-{amount}"
        amount_col = '#A0D468' if tipe == 'Income' else '#ED5565'  # Grass (hijau) vs Grapefruit (merah)

        def click(e):
            data = {
                "id": dataid,
                "title": label,
                "amount": amount,
                "date": date,
                "Type": tipe,
                "Category": sublabel
            }
            e.page.client_storage.set("Edit data", data)
            e.page.go('/income') if data["Type"] == "Income" else e.page.go('/expense')

        def hover(e):
            if e.data == "true":
                e.control.shadow = ft.BoxShadow(
                    spread_radius=2,
                    blur_radius=18,
                    color=ft.Colors.with_opacity(0.25, bgicon),
                    offset=ft.Offset(0, 5)
                )
            else:
                e.control.shadow = ft.BoxShadow(
                    spread_radius=0,
                    blur_radius=10,
                    color=ft.Colors.with_opacity(0.12, "#656D78"),
                    offset=ft.Offset(0, 3)
                )
                e.control.border = ft.border.all(1.5, "#E6E9ED")
            e.control.scale = 1.02 if e.data == "true" else 1
            e.control.update()

        return ft.Container(
            padding=12, 
            bgcolor="#FFFFFF", 
            border_radius=15,
            height=100,
            width=300,
            border=ft.border.all(1.5, "#E6E9ED"),
            ink=True, 
            on_click=click, 
            on_hover=hover,
            animate_scale=ft.Animation(300, ft.AnimationCurve.EASE_OUT),
            animate=ft.Animation(300, ft.AnimationCurve.EASE_OUT),
            shadow=ft.BoxShadow(
                spread_radius=0,
                blur_radius=10,
                color=ft.Colors.with_opacity(0.12, "#656D78"),
                offset=ft.Offset(0, 3)
            ),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Row(
                        spacing=15,
                        controls=[
                            ft.Container(
                                bgcolor=bgicon,
                                height=55,
                                width=55,
                                border_radius=12,
                                alignment=ft.alignment.center,
                                shadow=ft.BoxShadow(
                                    spread_radius=0,
                                    blur_radius=8,
                                    color=ft.Colors.with_opacity(0.3, bgicon),
                                    offset=ft.Offset(0, 3)
                                ),
                                content=ft.Icon(icon, color='white', size=28)
                            ),
                            ft.Column(
                                spacing=3,
                                alignment=ft.MainAxisAlignment.CENTER,
                                controls=[
                                    ft.Text(
                                        label, 
                                        size=16, 
                                        color="#434A54",
                                        weight=ft.FontWeight.BOLD
                                    ),
                                    ft.Text(
                                        sublabel, 
                                        size=13, 
                                        color="#656D78",
                                        weight=ft.FontWeight.W_500
                                    )
                                ]
                            )
                        ]
                    ),
                    ft.Row(
                        controls=[
                            ft.Column(
                                spacing=3,
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.END,
                                controls=[
                                    ft.Container(
                                        content=ft.Text(
                                            amount, 
                                            size=17, 
                                            color=amount_col,
                                            tooltip=f"{amount}",
                                            no_wrap=True, 
                                            overflow=ft.TextOverflow.ELLIPSIS,
                                            weight=ft.FontWeight.BOLD
                                        ),
                                        width=85
                                    ),
                                    ft.Text(
                                        date, 
                                        size=12, 
                                        color="#AAB2BD",
                                        weight=ft.FontWeight.W_500
                                    )
                                ]
                            ),
                            ft.IconButton(
                                ft.Icons.DELETE_FOREVER_ROUNDED, 
                                icon_color="#ED5565",
                                icon_size=26,
                                tooltip="Delete transaction",
                                on_click=lambda e: self.delete(dataid),
                                on_hover=self.delete_hover,
                                animate_scale=ft.Animation(200, ft.AnimationCurve.EASE_OUT)
                            )
                        ],
                        spacing=5
                    )
                ]
            )
        )
    
    def delete_hover(self, e):
        e.control.scale = 1.15 if e.data == "true" else 1
        e.control.icon_color = "#DA4453" if e.data == "true" else "#ED5565"
        e.control.update()
        
    def delete(self, Id):
        delete_data(Id)
        self.content = self.show_transaction()
        self.update()
        self.on_delete_update()