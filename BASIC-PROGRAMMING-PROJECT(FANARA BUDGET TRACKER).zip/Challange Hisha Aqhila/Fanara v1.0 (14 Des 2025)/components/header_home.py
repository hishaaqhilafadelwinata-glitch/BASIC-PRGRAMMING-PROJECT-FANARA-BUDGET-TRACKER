import flet as ft

class HeaderHome(ft.Container):
    def __init__(self, name):
        super().__init__()
        self.width= 400
        self.height= 120
        self.margin= ft.margin.only(top=1, right=1, left=1)
        self.alignment= ft.alignment.center
        self.border_radius= 15
        self.border= ft.border.all(1.5, "#E6E9ED")
        self.shadow= ft.BoxShadow(
            spread_radius=0,
            blur_radius=12,
            color=ft.Colors.with_opacity(0.08, "#656D78"),
            offset=ft.Offset(0, 4)
        )
        self.clip_behavior= ft.ClipBehavior.ANTI_ALIAS
        
        # Gunakan Stack untuk menempatkan gambar sebagai background
        self.content= ft.Stack(
            [
                # Background Image
                ft.Image(
                    src="colourful-abstract-shapes_78370-1451 (1).avif",
                    width=400,
                    height=120,
                    fit=ft.ImageFit.COVER,
                    opacity=0.4
                ),
                # Content di atas gambar
                ft.Container(
                    width=400,
                    height=120,
                    alignment=ft.alignment.center,
                    content=ft.Row(
                        controls=[
                            ft.Stack(
                                [
                                    ft.Container(
                                        width= 68,
                                        height= 68,
                                        border_radius= 18,
                                        padding= 10
                                    ),
                                    ft.Container(
                                        width= 64,
                                        height= 64,
                                        border_radius= 16,
                                        bgcolor= "#FFFFFF",
                                        alignment= ft.alignment.center,
                                        left= 2,
                                        top= 2,
                                        content=ft.Icon(
                                            ft.Icons.PERSON_ROUNDED, 
                                            size=34, 
                                            color="#5D9CEC"
                                        )
                                    ),
                                ],
                                width=68,
                                height=68
                            ),
                            ft.Container(width=15),
                            ft.Column([
                                ft.Text(
                                    "Welcome to Fanara Budget Tracker!", 
                                    size=12, 
                                    italic=True, 
                                    color="#2C3E50",
                                    weight=ft.FontWeight.W_600
                                ),
                                ft.Text(
                                    name, 
                                    size=20, 
                                    color="#1A252F",
                                    weight=ft.FontWeight.BOLD
                                )
                            ], 
                            spacing=3,
                            alignment=ft.MainAxisAlignment.CENTER),
                            ft.Container(
                                width= 48,
                                height= 48,
                                border_radius= 12,
                                bgcolor= "#FFFFFF",
                                alignment= ft.alignment.center,
                                border= ft.border.all(1.5, "#E6E9ED"),
                                shadow= ft.BoxShadow(
                                    spread_radius=0,
                                    blur_radius=8,
                                    color=ft.Colors.with_opacity(0.1, "#656D78"),
                                    offset=ft.Offset(0, 2)
                                ),
                                content=ft.IconButton(
                                    icon=ft.Icons.LOGOUT_ROUNDED,
                                    icon_color="#ED5565",
                                    tooltip="Logout",
                                    on_click= self.click_logout,
                                    icon_size=24,
                                    on_hover= self.logout_hover,
                                    animate_scale= ft.Animation(200, ft.AnimationCurve.EASE_OUT)
                                )
                            )
                        ], 
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=10
                    )
                )
            ]
        )

    def logout_hover(self, e):
        parent = e.control.parent
        if e.data == "true":
            parent.bgcolor = "#FDEEF0"
            parent.border = ft.border.all(1.5, "#ED5565")
            e.control.scale = 1.1
        else:
            parent.bgcolor = "#FFFFFF"
            parent.border = ft.border.all(1.5, "#E6E9ED")
            e.control.scale = 1
        parent.update()

    def click_logout(self, e):
        pop_up = ft.AlertDialog(
            title=ft.Text(
                "Log Out", 
                color="#434A54", 
                weight=ft.FontWeight.BOLD,
                size=20
            ),
            content=ft.Text(
                "Are you sure you want to logout?", 
                color="#656D78",
                size=15
            ),
            bgcolor="#FFFFFF",
            actions=[
                ft.ElevatedButton(
                    text="Yes",
                    on_click= lambda e: e.page.go('/login'),
                    color="#FFFFFF",
                    bgcolor="#ED5565",
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=10),
                        shadow_color="#ED5565",
                        elevation=3
                    ),
                    height=42,
                    width=100
                ),
                ft.ElevatedButton(
                    text="No",
                    on_click=lambda e: e.page.close(pop_up),
                    color="#656D78",
                    bgcolor='#E6E9ED',
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=10),
                        shadow_color="#CCD1D9",
                        elevation=2
                    ),
                    height=42,
                    width=100
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.SPACE_EVENLY,
            modal=True,
            shape=ft.RoundedRectangleBorder(radius=15)
        )
        e.page.open(pop_up)