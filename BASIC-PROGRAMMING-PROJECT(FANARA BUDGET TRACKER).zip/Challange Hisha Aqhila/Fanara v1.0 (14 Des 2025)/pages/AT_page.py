import flet as ft
from components.back_button import BackButton

class HeaderAddTransaction(ft.Container):
    def __init__(self):
        super().__init__()
        self.width= 400
        self.height= 120
        self.padding= 20
        self.margin= ft.margin.only(top=1, right=1, left=1)
        self.content= ft.Row(
            controls= [
                ft.Text(
                    "Add Transaction", 
                    size=22, 
                    color='#434A54',
                    weight=ft.FontWeight.BOLD
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER
        )

class IncomeExpenseCard(ft.Container):
    def __init__(self):
        super().__init__()
        self.content= ft.Column(
            controls=[
                ft.Column(
                    controls=[
                        ft.Text(
                            "Received any money today? Add it here.",
                            color="#656D78", 
                            italic=True, 
                            size=14,
                            weight=ft.FontWeight.W_500,
                            text_align=ft.TextAlign.CENTER
                        ),
                        self.create_card(
                            bgcolor='#F0F8ED',  # Light green background
                            icon=ft.Icons.ARROW_DOWNWARD_ROUNDED, 
                            label='Income', 
                            description='Add a new income transaction', 
                            adress='/income', 
                            iconcolor="#FFFFFF", 
                            iconbgcolor="#A0D468",  # Grass green
                            accentcolor="#A0D468"
                        )
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10
                ),
                ft.Container(height=15),
                ft.Column(
                    controls=[
                        ft.Text(
                            "What did you spend on today? Add it here.",
                            color="#656D78", 
                            italic=True, 
                            size=14,
                            weight=ft.FontWeight.W_500,
                            text_align=ft.TextAlign.CENTER
                        ),
                        self.create_card(
                            bgcolor='#FDEEF0',  # Light red background
                            icon=ft.Icons.ARROW_UPWARD_ROUNDED, 
                            label='Expense', 
                            description='Add a new expense transaction', 
                            adress='/expense', 
                            iconcolor="#FFFFFF", 
                            iconbgcolor="#ED5565",  # Grapefruit red
                            accentcolor="#ED5565"
                        ),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10
                ),
                ft.Container(height=100),
                BackButton()
            ],
            spacing=15,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
        self.padding= 20
        self.expand= True
        
    def create_card(self, bgcolor, icon, iconcolor, iconbgcolor, label, description, adress, accentcolor):
        return ft.Container(
            bgcolor= bgcolor,
            border_radius= 15,
            border= ft.border.all(1.5, ft.Colors.with_opacity(0.2, accentcolor)),
            width= 350,
            shadow= ft.BoxShadow(
                spread_radius=0,
                blur_radius=10,
                color=ft.Colors.with_opacity(0.1, "#656D78"),
                offset=ft.Offset(0, 3)
            ),
            content=ft.Row(
                [
                    ft.Container(
                        content= ft.Icon(icon, size=32, color=iconcolor),
                        alignment=ft.alignment.center,
                        bgcolor=iconbgcolor,
                        border_radius=14,
                        width=65,
                        height=65,
                        shadow= ft.BoxShadow(
                            spread_radius=0,
                            blur_radius=10,
                            color=ft.Colors.with_opacity(0.3, iconbgcolor),
                            offset=ft.Offset(0, 3)
                        )
                    ),
                    ft.Container(width=18),
                    ft.Column(
                        controls=[
                            ft.Text(
                                label, 
                                size=24, 
                                color="#434A54", 
                                weight=ft.FontWeight.BOLD
                            ),
                            ft.Text(
                                description, 
                                size=13, 
                                color="#656D78",
                                weight=ft.FontWeight.W_500
                            )
                        ],
                        spacing=4,
                        alignment=ft.MainAxisAlignment.CENTER
                    )
                ], 
                alignment= ft.MainAxisAlignment.START,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            ),
            padding= 22,
            margin= ft.margin.symmetric(vertical=5),
            ink= True,
            on_click= lambda e: e.page.go(adress),
            ink_color= ft.Colors.with_opacity(0.1, accentcolor),
            on_hover= lambda e: self.hover(e, accentcolor),
            animate_scale= ft.Animation(300, ft.AnimationCurve.EASE_OUT),
            animate= ft.Animation(300, ft.AnimationCurve.EASE_OUT),
            data= accentcolor  # Store accent color in data
        )
        
    def hover(self, e, accentcolor):
        if e.data == 'true':
            e.control.scale= 1.02
            e.control.border= ft.border.all(1.5, accentcolor)
            e.control.shadow= ft.BoxShadow(
                spread_radius=2,
                blur_radius=18,
                color=ft.Colors.with_opacity(0.25, accentcolor),
                offset=ft.Offset(0, 6)
            )
        else:
            e.control.scale= 1
            e.control.border= ft.border.all(1.5, ft.Colors.with_opacity(0.2, accentcolor))
            e.control.shadow= ft.BoxShadow(
                spread_radius=0,
                blur_radius=10,
                color=ft.Colors.with_opacity(0.1, "#656D78"),
                offset=ft.Offset(0, 3)
            )
        e.control.update()    

class ATPage(ft.View):
    def __init__(self):
        super().__init__(route='/transaction')
        self.padding= 0
        self.bgcolor= "#FFFFFF"
        self.horizontal_alignment= ft.CrossAxisAlignment.CENTER
        self.controls=[
            HeaderAddTransaction(),
            IncomeExpenseCard()
        ]