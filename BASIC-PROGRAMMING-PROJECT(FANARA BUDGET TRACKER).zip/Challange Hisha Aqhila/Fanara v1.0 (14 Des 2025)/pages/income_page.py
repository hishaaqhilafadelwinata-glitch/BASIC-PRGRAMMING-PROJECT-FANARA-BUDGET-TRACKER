import os
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)

import flet as ft
import datetime
from utils.transactions import save_data, edit_data
from components.commons_IncExp import Header, Input, Date, DialPad, CategoryButton
from components.back_button import BackButton

class IncomePage(ft.View):
    def __init__(self):
        super().__init__(route='/income')
        self.bgcolor= "#FFFFFF"
        self.scroll= ft.ScrollMode.HIDDEN
        self.padding= 0
        self.horizontal_alignment= ft.CrossAxisAlignment.CENTER
        self.is_edit_mode= None
        self.edit_id=None

        self.header= Header(on_save= self.save, 
                            label="Add New Income",
                            labelclr="#0A1E3D",
                            bgcolor="#C9DEF0")
        self.input_title = Input(change=self.check_input)
        self.input_date = Date()
        self.input_amount = DialPad()
        self.cat_btn = [
            [ft.Icons.MONETIZATION_ON, '#0E7CC1','Salary', 'Salary'], 
            [ft.Icons.CASES, '#1E4478', 'Dividen', 'Dividen'],
            [ft.Icons.WALLET_GIFTCARD, '#8BBFD9', 'Gift', 'Gift'],
            [ft.Icons.MORE_HORIZ, '#0A1E3D', 'Others', 'Others']
        ]
        self.data_btn = CategoryButton(self.cat_btn)
        self.controls=[
            self.header,
            self.data_btn,
            self.input_title,
            self.input_date,
            self.input_amount,
            ft.Container(height=40),
            BackButton()
        ]
        self.spacing=0
    def save(self, e):
        title = self.input_title.input_field.value
        date = self.input_date.date_picker.value
        cat = self.data_btn.selected_value
        if date == None:
            final_date = datetime.datetime.now().strftime("%d %b %Y")
        else:
            final_date= date.strftime("%d %b %Y")
        amount = self.input_amount.display.value
        if self.is_edit_mode:
            edit_data(self.edit_id, title, final_date, amount, tipe="Income", category=cat)
            e.page.client_storage.remove("Edit data")
        else:
            save_data(title, final_date, amount, tipe="Income", category=cat)
            self.input_title.input_field.value=''
            self.input_amount.display.value='0'
        e.page.snack_bar = ft.SnackBar(ft.Text("Data Saved!"), bgcolor='#0E7CC1')
        e.page.go('/home')
        e.page.open(e.page.snack_bar)
        e.page.update()
        
    def check_input(self, e):
        title = self.input_title.input_field.value
        strip_title = title.strip()
        self.header.save_btn.disabled = True if not strip_title else False
        self.header.save_btn.update()
    
    def did_mount(self):
        data_edit= self.page.client_storage.get("Edit data")
        if data_edit:
            self.is_edit_mode= True
            self.edit_id= data_edit['id']
            self.input_title.input_field.value= data_edit['title']
            self.input_amount.display.value= data_edit['amount'].replace("+", "").replace("-","")
            str_date= data_edit['date']
            self.input_date.date_picker.value= datetime.datetime.strptime(str_date, "%d %b %Y")
            self.input_date.date_text.value= str_date
            self.header.label_txt.value= "Edit Income"
            self.header.save_btn.disabled= False
            self.page.update()