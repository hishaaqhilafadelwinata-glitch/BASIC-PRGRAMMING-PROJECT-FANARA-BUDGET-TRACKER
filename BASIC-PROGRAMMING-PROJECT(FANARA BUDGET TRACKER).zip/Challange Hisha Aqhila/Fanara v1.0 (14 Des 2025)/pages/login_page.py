import flet as ft
import json
import os
folder = "Database"
file = "Username.json"
current_dir = os.path.abspath(__file__)
pages_folder = os.path.dirname(current_dir)
database_folder = os.path.join(pages_folder, folder)
full_path = os.path.join(database_folder, file)

class LoginTitle(ft.Container):
    def __init__(self):
        super().__init__()
        self.padding=ft.padding.only(left=20, right=20, top=50, bottom=10)
        self.margin=ft.margin.only(left=20, right=20, top=50, bottom=10)
        self.content= ft.Column([
            ft.Container(
                width=100,
                height=100,
                border_radius=15,
                bgcolor="#4FC1E9",  # Aqua - warna biru cerah
                alignment=ft.alignment.center,
                shadow=ft.BoxShadow(
                    spread_radius=2,
                    blur_radius=20,
                    color=ft.Colors.with_opacity(0.3, "#4FC1E9"),
                    offset=ft.Offset(0, 8)
                ),
                content=ft.Icon(ft.Icons.PERSON,
                    size=60,
                    color= '#FFFFFF')
            ),
            ft.Text('Welcome!',  size= 38, color = '#434A54', weight=ft.FontWeight.BOLD),  # Dark Gray
            ft.Text("How should we call you?", size = 18, color= '#656D78', italic=True)],  # Medium Gray
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
        self.alignment=ft.alignment.center

class InputName(ft.TextField):
    def __init__(self):
        super().__init__()
        self.label='Fill in here'
        self.hint_text= 'e.g Nadya Renata'
        self.color= "#434A54"  # Dark Gray
        self.text_size= 14
        self.text_style=ft.TextStyle(weight=ft.FontWeight.BOLD)
        self.label_style=ft.TextStyle(color="#656D78")  # Medium Gray
        self.focused_border_color= "#4FC1E9"  # Aqua
        self.border_color= "#E6E9ED"  # Light Gray
        self.value = ""
        self.border_radius= 10
        self.filled= True
        self.fill_color= '#FFFFFF'
        self.text_align=ft.TextAlign.CENTER
        self.width= 250
        self.height= 55


class ContinueButton(ft.ElevatedButton):
    def __init__(self, input_name):
        super().__init__()
        self.text = 'Continue'
        self.bgcolor = "#4FC1E9"  # Aqua - warna utama
        self.color = "#FFFFFF"
        self.width = 200
        self.height = 50
        self.input_ref = input_name
        self.on_click= self.save_name 
        self.style= ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=10),
            shadow_color="#4FC1E9",
            elevation=8
        )
        self.on_hover= self.hover
        self.animate_scale= ft.Animation(300, ft.AnimationCurve.EASE_OUT)
        
    def hover(self, e):
        if e.data == 'true':
            e.control.scale=1.05
            e.control.elevation=12
            e.control.bgcolor="#48CFAD"  # Mint - warna hover
        else:
            e.control.scale=1
            e.control.elevation=8
            e.control.bgcolor="#4FC1E9"  # Aqua - warna normal
        e.control.update()
        
    def save_name(self, e):
        username = self.input_ref.value.strip()
        if not username:
            e.page.snack_bar = ft.SnackBar(
                ft.Text("Please enter your name!", 
                       color="#FFFFFF",
                       weight=ft.FontWeight.BOLD), 
                bgcolor='#656D78',  # Medium Gray
                action="OK",
                action_color="#E6E9ED"  # Light Gray
            )
            e.page.open(e.page.snack_bar)
            e.page.update()
        else:
            e.page.client_storage.set("Saved Name", username)
            e.page.go('/home')
        
class LoginContent(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        self.border_radius= 12
        self.bgcolor= "#FFFFFF"
        self.padding= 40
        self.shadow= ft.BoxShadow(
            spread_radius=0,
            blur_radius=30,
            color=ft.Colors.with_opacity(0.12, "#656D78"),  # Medium Gray shadow
            offset=ft.Offset(0, 10)
        )
        name= InputName()
        button = ContinueButton(input_name=name)
        self.content= ft.Column(
            controls=[
                ft.Container(height=20),
                ft.Container(
                    width=100,
                    height=100,
                    border_radius=15,
                    bgcolor="#4FC1E9",  # Aqua
                    alignment=ft.alignment.center,
                    shadow=ft.BoxShadow(
                        spread_radius=2,
                        blur_radius=20,
                        color=ft.Colors.with_opacity(0.3, "#4FC1E9"),
                        offset=ft.Offset(0, 8)
                    ),
                    content=ft.Icon(ft.Icons.PERSON,
                        size=60,
                        color= '#FFFFFF')
                ),
                ft.Container(height=30),
                ft.Column(
                    controls=[
                        ft.Text("Welcome!", size=32, 
                        color="#434A54", weight=ft.FontWeight.BOLD),  # Dark Gray
                        ft.Container(height=5),
                        ft.Text("How should we call you?", size=16, 
                        color="#656D78", italic=True)  # Medium Gray
                    ],
                    spacing=0,
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                ft.Container(height=30),
                name,
                ft.Container(height=10),
                button,
                ft.Container(height=20),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER, 
            spacing=0
        )

class Login(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route='/login')
        self.page=page
        self.main_content= LoginContent()
        self.bgcolor= "#F5F7FA" 
        self.controls=[
            ft.Container(
                content=self.main_content,
                bgcolor="#F5F7FA",
                expand=True,
                alignment=ft.alignment.center,
                padding=20
            )
        ]
        self.padding=0
        self.horizontal_alignment= ft.CrossAxisAlignment.CENTER
        
    def resize_content(self, e):
        if self.page:
            new_width= min(self.page.window.width*0.9, 400)
            self.main_content.width= new_width
            if self.main_content.page:
                self.main_content.update()