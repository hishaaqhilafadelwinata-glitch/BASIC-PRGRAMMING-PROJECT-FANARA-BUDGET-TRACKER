import flet as ft
from components.header_home import HeaderHome
from components.dashboard_cards import  DashboardCard
from components.transaction_list import TransactionList

class HomeContent(ft.Container):
    def __init__(self, user):
        super().__init__()
        self.alignment= ft.alignment.center
        self.dashboard= DashboardCard()
        self.content= ft.Column(
            controls=[
                HeaderHome(name=user),
                self.dashboard,
                TransactionList(on_delete_update=self.dashboard.update_data)
            ],
            spacing=10,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )

class PlusButton(ft.FloatingActionButton):
    def __init__(self):
        super().__init__()
        self.icon= ft.Icons.ADD
        self.bgcolor= "#0E7CC1"
        self.tooltip='Add Transaction'
        self.foreground_color= "#FFFFFF"
        self.on_click= self.click
        self.shape= ft.RoundedRectangleBorder(radius=15)
        self.elevation= 8
    def click(self, e):
        if e.page.client_storage.contains_key("Edit data"):
            e.page.client_storage.remove("Edit data")
        e.page.go('/transaction')

class Home(ft.View):
    def __init__(self, username):
        super().__init__(route='/home')
        self.floating_action_button= PlusButton()
        self.main_content= HomeContent(user=username)
        self.controls=[
            self.main_content
        ]
        self.padding=0
        self.bgcolor='#FFFFFF'
        self.horizontal_alignment= ft.CrossAxisAlignment.CENTER