import flet as ft

class Icon(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        self.content= ft.Column(
            controls=[
                ft.Container(
                    width= 110,
                    height= 110,
                    border_radius= 22,
                    gradient= ft.LinearGradient(
                        begin=ft.alignment.top_left,
                        end=ft.alignment.bottom_right,
                        colors=["#5D9CEC", "#4FC1E9"]
                    ),
                    alignment=ft.alignment.center,
                    shadow=ft.BoxShadow(
                        spread_radius=2,
                        blur_radius=25,
                        color=ft.Colors.with_opacity(0.35, "#5D9CEC"),
                        offset=ft.Offset(0, 8)
                    ),
                    content=ft.Icon(
                        ft.Icons.ACCOUNT_BALANCE_WALLET_ROUNDED,
                        size=65,
                        color="#FFFFFF"
                    )
                )
            ],
            horizontal_alignment= ft.CrossAxisAlignment.CENTER
        )

class Button(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        self.content= ft.Column(
            controls=[
                ft.ElevatedButton(
                    width=220, 
                    height=55, 
                    color='#FFFFFF',
                    text='Get Started', 
                    bgcolor="#5D9CEC",
                    style=ft.ButtonStyle(
                        shape= ft.RoundedRectangleBorder(radius=12),
                        shadow_color="#5D9CEC",
                        elevation=8
                    ),
                    on_click=self.click,
                    on_hover=self.hover,
                    animate_scale=ft.Animation(300, ft.AnimationCurve.EASE_OUT)
                )
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
        
    def hover(self, e):
        if e.data == 'true':
            e.control.scale= 1.05
            e.control.elevation= 12
            e.control.bgcolor= "#4A89DC"
        else:
            e.control.scale= 1
            e.control.elevation= 8
            e.control.bgcolor= "#5D9CEC"
        e.control.update()
        
    def click(self, e):
        e.page.go('/home') if e.page.client_storage.contains_key("Saved Name") else e.page.go('/login')

class StartContent(ft.Container):
    def __init__(self):
        super().__init__()
        self.alignment= ft.alignment.center
        self.bgcolor= "#FFFFFF"
        self.border_radius= 20
        self.shadow= ft.BoxShadow(
            spread_radius=2,
            blur_radius=30,
            color=ft.Colors.with_opacity(0.12, "#656D78"),
            offset=ft.Offset(0, 10)
        )
        self.padding= 45
        self.content= ft.Column(
            controls=[
                ft.Container(height=20),
                ft.Container(
                    width= 130,
                    height= 130,
                    border_radius= 25,
                    gradient= ft.LinearGradient(
                        begin=ft.alignment.top_left,
                        end=ft.alignment.bottom_right,
                        colors=["#5D9CEC", "#4FC1E9", "#48CFAD"]
                    ),
                    alignment=ft.alignment.center,
                    shadow=ft.BoxShadow(
                        spread_radius=3,
                        blur_radius=30,
                        color=ft.Colors.with_opacity(0.4, "#5D9CEC"),
                        offset=ft.Offset(0, 10)
                    ),
                    content=ft.Icon(
                        ft.Icons.ACCOUNT_BALANCE_WALLET_ROUNDED,
                        size=75,
                        color="#FFFFFF"
                    )
                ),
                ft.Container(height=35),
                ft.Text(
                    "Fanara Budget Tracker",
                    size=30,
                    weight=ft.FontWeight.BOLD,
                    color="#434A54",
                    text_align=ft.TextAlign.CENTER
                ),
                ft.Container(height=12),
                ft.Text(
                    "Manage your finances effortlessly",
                    size=15,
                    color="#AAB2BD",
                    text_align=ft.TextAlign.CENTER,
                    italic=True,
                    weight=ft.FontWeight.W_500
                ),
                ft.Container(height=45),
                Button(),
                ft.Container(height=25),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER
        )

class StartPage(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route='/')
        self.main_content= StartContent()
        self.page= page
        self.controls=[
            ft.Container(
                content=self.main_content,
                gradient= ft.LinearGradient(
                    begin=ft.alignment.top_center,
                    end=ft.alignment.bottom_center,
                    colors=["#F5F7FA", "#E6E9ED"]
                ),
                expand=True,
                alignment=ft.alignment.center,
                padding=20
            )
        ]
        self.padding= 0
        self.spacing= 0
        self.bgcolor= "#F5F7FA"
        
    def resize_content(self, e):
        if self.page:
            new_width= min(self.page.window.width * 0.9, 400)
            self.main_content.width= new_width
            if self.main_content.page:
                self.main_content.update()